const test = require('tape')

test('dummmy test', assert => {
  assert.plan(1)
  assert.ok(true)
})
